import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import static java.lang.Math.*;

/**
 * Created by mac on 18/3/21.
 */
public class test {
    public static void main(String[] args) {
        System.out.println(nth_root("7",4));
        System.out.println(nth_root("1600000.67",3));
        System.out.println(d2f("123.45"));

        double r_mp = 2;
        String r_p = "2";
        for (int j=0;j<60;j++){
            r_mp = Math.pow(r_mp, 0.5);
            r_p = power(r_p,"0.5");
        }
        System.out.println("r_math_p: " + r_mp);
        System.out.println("r_p: " + r_p);


    }

    static String nth_root(String a, int b){
        BigDecimal value = new BigDecimal(a);
        BigDecimal exp = new BigDecimal(a.split("\\.")[0]);
        BigDecimal fra = value.subtract(exp);

        int n = b;
        BigDecimal B = new BigDecimal("0");
        BigDecimal r = new BigDecimal("0");
        BigDecimal alpha = new BigDecimal("0");
        int beta = 0;
        BigDecimal y = new BigDecimal("0");
        BigDecimal y_l = new BigDecimal("0");

        B = BigDecimal.TEN;
        int c = 0;
        boolean exact = false;

        List<Integer> exp_result = new ArrayList<>();
        List<Integer> fra_result = new ArrayList<>();

        //string concatenation creates a new immutable string each time you use it
        StringBuilder sb = new StringBuilder();

        int eptr = 0;
        int fptr = 2;

        while (!(c > 40 || exact)){
            //System.out.println("r: " + r.toPlainString() + " alpha: " + alpha.toPlainString() + " beta: " + beta + " y: " + y.toPlainString() + " y_l" + y_l.toPlainString());
            //real part
            if (eptr < exp.toPlainString().length()) {
                //define alpha
                if (exp.toPlainString().length() % n != 0 && eptr == 0) {
                    String alpha_s = exp.toPlainString().substring(eptr,exp.toPlainString().length()%n);
                    alpha = new BigDecimal(alpha_s);
                    eptr = exp.toPlainString().length()%n;
                } else {
                    String alpha_s = exp.toPlainString().substring(eptr,eptr + n);
                    alpha = new BigDecimal(alpha_s);
                    eptr += n;
                }
                beta = 0;
                //System.out.println("r"+r+"alp"+alpha);
                //define beta
                while (B.multiply(y).add(new BigDecimal(beta)).pow(n).compareTo(y.pow(n).add(r).multiply(B.pow(n)).add(alpha)) <= 0){
                    beta += 1;
                }
                beta -= 1;
                //System.out.println(beta);
                // define y (y_0) and r
                // y = B * y + beta
                y_l = y;
                y = B.multiply(y).add(new BigDecimal(beta));
                r = B.pow(n).multiply(r).add(alpha).subtract(y.pow(n).subtract(B.pow(n).multiply(y_l.pow(n))));

                exp_result.add(beta);
            }else{
                // BigD to int to string
                //System.out.println(Double.toString(fra.doubleValue()));
                if (fptr < fra.toPlainString().length()) {
                    // BIgD to int to string to int
                    // can't apply BIgD to string to int, it will convert to +E8
                    if (fptr + n <= fra.toPlainString().length()) {
                        String alpha_s = fra.toPlainString().substring(fptr,fptr + n);
                        //System.out.println(fra.toString());
                        alpha = new BigDecimal(alpha_s);
                    }else{
                        String alpha_s = fra.toPlainString().substring(fptr,fra.toPlainString().length());;
                        int scale = n - (alpha_s.length() % n);
                        alpha = (new BigDecimal(alpha_s)).multiply(BigDecimal.TEN.pow(scale));;
                    }
                    fptr += n;
                }else{
                    alpha = new BigDecimal("0");
                }

                beta = 0;
                //System.out.println("r"+r+"alp"+alpha);
                //define beta
                while (B.multiply(y).add(new BigDecimal(beta)).pow(n).compareTo(y.pow(n).add(r).multiply(B.pow(n)).add(alpha)) <= 0){
                    beta += 1;
                }
                beta -= 1;
                //System.out.println(beta);
                // define y (y_0) and r
                y_l = y;
                y = B.multiply(y).add(new BigDecimal(beta));
                r = B.pow(n).multiply(r).add(alpha).subtract(y.pow(n).subtract(B.pow(n).multiply(y_l.pow(n))));

                fra_result.add(beta);
            }
            exact = (r.compareTo(new BigDecimal("0")) == 0) && fptr >= fra.toPlainString().length();

            c+=1;
        }

        //System.out.println("print exp");
        for (Integer i : exp_result){
            sb.append(i.toString());
        }
        //System.out.println("print fra");
        sb.append(".");
        for (Integer i : fra_result){
            sb.append(i.toString());
        }

        return sb.toString();
    }

    /*
      Converts a a.b to fraction
      @param a
      @return String num/den
    */
    static String d2f (String a){
        BigDecimal number = new BigDecimal(a);
        //check whether decimal
        if (a.split("\\.").length < 2){
            return number.toPlainString();
        }
        //remove decimal, otherwise, 10.00
        BigDecimal den = BigDecimal.TEN.pow(a.split("\\.")[1].length());
        BigDecimal num = (new BigDecimal(a.split("\\.")[0]).multiply(den)).add(new BigDecimal(a.split("\\.")[1]));
        return reduceFraction(num,den);
    }

    /*
      Convert the numerator and denominator to their minimum values where no
      further cancellations are possible. Find GCD

      @param num
      @param den
      @return 10/3 or 10(10.00)
    */
    static String reduceFraction(BigDecimal num,BigDecimal den){
        BigInteger num_bi = num.toBigInteger();
        BigInteger den_bi = den.toBigInteger();
        BigInteger gcd = den_bi.gcd(num_bi);

        BigInteger result_num = num_bi.divide(gcd);
        BigInteger result_den = den_bi.divide(gcd);
        if (result_den.compareTo(BigInteger.ONE) == 0){
            return result_num.toString();
        }
        return result_num.toString() + "/" + result_den.toString();
    }

    static String power(String base, String exponent){

        String frac = d2f(exponent);
        BigDecimal den_bg = new BigDecimal(frac.split("\\/")[1]);
        BigDecimal num_bg = new BigDecimal(frac.split("\\/")[0]);
        BigDecimal base_bg = new BigDecimal(base);
        return nth_root(base_bg.pow(num_bg.intValue()).toPlainString(),den_bg.intValue());
    }

}







/*
Read the fraction number as a string. Convert it to a BigDecimal.
Split it into two parts. One will be the numerator and other will be denominator. This is stored in an array.
To remove the decimal, we need a multiplier of 10 with zeroes equal to the number of digits after the decimal. Keeping this is mind:
    i. multiply 10 by the length of digits after decimal. This will be the lenngth of second element of the array in Step 2. This will give us the denominator of the fraction.
    ii. Now the numerator can be determined by multiplying the part of the number before decimal (first element of array from Step 2) by the denominator determined in the previous step and adding the part of the number after decimal (second element of array from Step 2).
This gives us the numerator and denominator parts of our fraction. For example, if the number entered was 2.45, then our algorithm till this step will give us 245/100.
Now we only need to reduce it to its lowest terms. For this we determine the greatest common divisor(gcd) of numerator and denominator and divide numerator and denominator (from Step 3) to get the fraction in lowest terms. This code is written in reduceFraction method of the attached class.
 */